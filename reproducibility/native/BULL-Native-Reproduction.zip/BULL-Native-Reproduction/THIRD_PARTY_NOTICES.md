# Third-party materials

BULL's original source uses GPL-2.0-or-later (see LICENSE). This does not relicense
third-party dependencies, media, model weights or operating-system components.
No third-party Python packages or guest images are vendored in the Git tree.

## Python and tooling

The core package uses Python's standard library. CPython has its own
[PSF license and incorporated notices](https://docs.python.org/3/license.html).
Installed development metadata reviewed on 2026-09-23 records:

| Package | Reviewed version | Declared license | Role |
|---|---|---|---|
| pytest | 9.1.1 | MIT | Tests |
| cryptography | 50.0.1 | Apache-2.0 OR BSD-3-Clause | Test credentials and optional custom hardware verifier |
| setuptools | 84.0.0 | MIT | Packaging |
| wheel | 0.48.0 | MIT | Packaging |
| build | 1.6.1 | MIT | Source distribution and wheel validation |
| mcp | 2.2.0 | MIT | Optional local MCP connector; metadata reviewed 2026-09-27 |
| grpcio | 1.84.0 | Apache-2.0 | Optional OpenShell extension services; reviewed 2026-09-28 |
| protobuf | 7.36.2 | BSD-3-Clause | Optional OpenShell extension services; reviewed 2026-09-28 |

Version ranges in pyproject.toml permit other versions. These are direct tools,
not an exhaustive dependency SBOM. Redistributors must retain the notices for
the actual dependency versions they bundle. Installing from package repositories
does not add those packages to BULL's source license.

The collector's Wrangler tool is an external Cloudflare development dependency;
consult [its source and license](https://github.com/cloudflare/workers-sdk).
`src/bulldog/openshell/_proto/` holds stubs generated from NVIDIA OpenShell's
Apache-2.0 protocol definitions (tag v0.1.2); see its README for provenance.
OpenShell itself is an external dependency with its own notices.

TLA+ tools, OpenSSH, OpenSSL, libseccomp, util-linux, QEMU, ClamAV and the system
build toolchain are external dependencies with their own notices.

## Guest images

A generated root filesystem bundles separately licensed packages, including Linux,
Python, Bash, ClamAV and libraries selected by Buildroot. Use the **actual build's**
legal-info manifests, license texts, corresponding sources, patches and configs;
this short inventory cannot substitute for them. Qboot is built separately and
must have its source and license included too. See [DISTRIBUTION.md](docs/DISTRIBUTION.md).

## Presentation assets

The paper is the user-supplied author-review manuscript by Luis Minier, published
without modification; [its manifest](site/assets/papers/manifest.json) records
provenance and hash. It is not peer-reviewed.

The externally hosted explainer uses synthetic Piper `en_US-libritts-high`
narration, speaker 0. The [voice model card](https://huggingface.co/rhasspy/piper-voices/blob/main/en/en_US/libritts/high/MODEL_CARD)
identifies [LibriTTS](https://www.openslr.org/60/) by Heiga Zen and collaborators
and its [CC BY 4.0 license](https://creativecommons.org/licenses/by/4.0/).
The project synthesized narration for this video; the voice is not presented as
a named person's recording or endorsement. Attribution is also retained in the
[media manifest](site/assets/explainer/manifest.json). Model weights, rendering
tools and video bytes are not bundled in this repository.

A model's license is separate from BULL's. Operators obtain their own local model
and check its terms; the Qwen test result does not grant rights to model weights.

The hardware source targets external Raspberry Pi Pico SDK 2.2.0 (BSD-3-Clause),
its pinned TinyUSB dependency (MIT), ARM GNU/newlib tools and picotool. Their
sources and licenses are obtained separately; no SDK, toolchain, private keys or
flashed device images are bundled in Git.
