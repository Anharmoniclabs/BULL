# Native BULL–OpenShell reproduction

This runs NVIDIA OpenShell, Docker sandboxes, the BULL service and real HTTP
requests from inside those sandboxes. It runs OpenShell alone, then OpenShell
with BULL, against a host-side HTTP receiver. The receiver saves every request
body before answering. OpenShell supplies its own logs.

The new runner has not completed a native run here. This host lacks Docker.
The included host check records BLOCKED. No passing native result is supplied.

## Run

Use a Linux x86-64 host with Python 3.12, Git, OpenSSL and a working **local**
Docker daemon. The gateway and receiver run on that host. A remote Docker
context is not supported. Docker must be able to start OpenShell's isolated
sandboxes; a reachable daemon alone does not establish this.

If OpenShell is not built, on an Ubuntu/Debian host run from this package:

```sh
python3 tools/prepare_codespace_openshell.py \
  --source /tmp/bull-native-OpenShell \
  --report /tmp/bull-native-build.json --jobs 2
```

This installs build packages and Rust 1.95.0 and builds OpenShell commit
6648bd0c290efbc41ba131ee9831ee45cd431f94. It requires network access, disk
space and root or passwordless sudo. It does not install Docker. Keep the build
report with the eventual results. Existing source at a different commit is refused.

Then run with new, absolute output paths:

```sh
bash examples/saf_native/run.sh \
  /tmp/bull-native-OpenShell /tmp/bull-native-results
```

Python dependencies are bundled. Docker image construction still needs network
access. Upstream base images and apt packages are not all pinned; exact resulting
image IDs are recorded. This is a repeatable test procedure, not a bit-identical
OS/image build. Reuse or export those Docker images when repeating the same environment.

## What to read

- `report.json`: PASS, FAIL or BLOCKED; never substitutes fixture results.
- `native/results.json`: individual expected and observed outcomes.
- `native/destination.jsonl`: actual request headers, bytes, digest and timestamp,
  written and fsynced before the receiver responds.
- `native/commands.jsonl`: commands, process exit codes and full output.
- `native/A-openshell-only/` and `native/B-openshell+bull/`: per-phase case
  records and original runtime logs, retained even if the test fails.
- `provenance.json`, `images.jsonl`, `SHA256SUMS`: source, binary, image and result identities.

The receiver and test driver share a host process; this is project-operated
evidence, not independent attestation. Hashes detect changes relative to the
manifest, not fabrication by an operator controlling both. Runtime folders
contain disposable test keys and local state; retain them locally.

## Scope

The test exercises permission denial, OpenShell path denial, approval/reuse,
policy widening, selected bypass attempts and a real BULL process kill/restart.
It uses harmless test request bodies and automated local approval. These are
real executed requests, but they do not prove a human owner approved an action.

It does not invoke the loopback qualification script or the fault authority that
injects Python exceptions. DNS failure is not counted as containment: the older
probe lacked a working control. C6 checks only provider attachment and two
environment views, not every way a credential could be read. C10 joins the native
shorthand logs heuristically; it does not establish cryptographically bound
request identity. No MCP end-to-end session, replica recovery or complete SAF
acceptance is claimed.

The old fixture reproduction and its results are excluded from this archive.
