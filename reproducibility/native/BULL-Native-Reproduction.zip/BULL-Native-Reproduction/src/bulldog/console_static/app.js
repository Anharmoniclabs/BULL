(function () {
  "use strict";
  var S = { snapshot: null, view: "overview", q: "" };
  // The console prints its URL with a per-run access key in the fragment,
  // which is never sent to the server or in a Referer. Keep it for this tab.
  var KEY = (function () {
    var m = /(?:^#|&)token=([A-Za-z0-9_-]+)/.exec(location.hash),
      k = null;
    try {
      if (m) sessionStorage.setItem("bull-console-key", m[1]);
      k = sessionStorage.getItem("bull-console-key");
    } catch (e) {
      k = m ? m[1] : null;
    }
    if (m) history.replaceState(null, "", location.pathname + location.search);
    return k || (m ? m[1] : "");
  })();
  function api(path, options) {
    options = options || {};
    options.headers = Object.assign({}, options.headers, {
      Authorization: "Bearer " + KEY,
    });
    return fetch(path, options);
  }
  var $ = function (id) {
      return document.getElementById(id);
    },
    $$ = function (q) {
      return Array.prototype.slice.call(document.querySelectorAll(q));
    };
  function esc(v) {
    return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function num(v) {
    return Number(v || 0).toLocaleString();
  }
  function pct(v) {
    return Math.round(Number(v || 0) * 100) + "%";
  }
  function cls(v) {
    return String(v || "pending")
      .toLowerCase()
      .replace(/[^a-z0-9_-]/g, "");
  }
  function ago(v) {
    if (!v) return "not recorded";
    var d = Date.now() - Date.parse(v),
      s = Math.floor(d / 1000);
    if (!isFinite(d) || d < 0) return "just now";
    if (s < 60) return s + "s ago";
    if (s < 3600) return Math.floor(s / 60) + "m ago";
    return Math.floor(s / 3600) + "h ago";
  }
  function hash(v) {
    v = String(v || "");
    return v ? v.slice(0, 12) + "…" + v.slice(-7) : "not available";
  }
  function toast(m, k) {
    var n = $("toast");
    n.textContent = m;
    n.className = "toast show " + (k || "");
    clearTimeout(toast.t);
    toast.t = setTimeout(function () {
      n.className = "toast";
    }, 3000);
  }
  function setView(v) {
    S.view = v;
    $$(".nav-item").forEach(function (n) {
      n.classList.toggle("active", n.dataset.view === v);
    });
    $$(".view").forEach(function (n) {
      n.classList.toggle("active", n.dataset.viewPanel === v);
    });
    window.scrollTo(0, 0);
    search();
  }
  function decision(label, value, c, note) {
    return (
      '<article class="decision-card ' +
      c +
      '" data-searchable><b>' +
      esc(label) +
      "</b><strong>" +
      num(value) +
      "</strong><small>" +
      esc(note) +
      "</small></article>"
    );
  }
  function renderDecisions(x) {
    var d = (x.policy || {}).decisions || {},
      h =
        decision("ALLOW", d.ALLOW, "allow", "recent ledger window") +
        decision("SANDBOX", d.SANDBOX, "sandbox", "recent ledger window") +
        decision("REVIEW", d.ESCALATE, "review", "ESCALATE decisions") +
        decision("DENY", d.DENY, "deny", "recent ledger window");
    $("decision-cards").innerHTML = h;
    $("policy-decision-detail").innerHTML = h;
    $("policy-rule").textContent =
      ((x.policy || {}).policy_meta || {}).detail || "Policy state unavailable.";
  }
  var icons = {
    filesystem: "▰",
    network: "◎",
    process: "⌘",
    secrets: "▣",
    persistence: "◉",
    spawn: "✥",
  };
  function cap(i) {
    return (
      '<article class="cap-card" data-searchable><span class="dot ' +
      cls(i.status) +
      '"></span><span class="cap-icon">' +
      (icons[i.id] || "◆") +
      "</span><h3>" +
      esc(i.title) +
      "</h3><p>" +
      esc(i.detail) +
      "</p></article>"
    );
  }
  function renderCaps(x) {
    var a = (x.capabilities || {}).items || [];
    $("capability-grid").innerHTML =
      a.map(cap).join("") || '<div class="empty-state">No capability data.</div>';
    $("capability-detail-grid").innerHTML = a
      .map(function (i) {
        return (
          '<article class="cap-detail" data-searchable><span class="control-status ' +
          cls(i.status) +
          '">' +
          esc(i.status) +
          "</span><h3>" +
          esc(i.title) +
          "</h3><p>" +
          esc(i.detail) +
          "</p><ul>" +
          (i.capabilities || [])
            .map(function (c) {
              return "<li>" + esc(c) + "</li>";
            })
            .join("") +
          "</ul></article>"
        );
      })
      .join("");
  }
  function iso(i) {
    return (
      '<article class="iso-card ' +
      cls(i.status) +
      '" data-searchable><b>' +
      esc(i.title) +
      "</b><p>" +
      esc(i.status) +
      " · " +
      esc(i.detail || i.control_id) +
      "</p></article>"
    );
  }
  function ctrl(i) {
    return (
      '<article class="control-card" data-searchable><div class="control-head"><h3>' +
      esc(i.title) +
      '</h3><span class="control-status ' +
      cls(i.status) +
      '">' +
      esc(i.status) +
      "</span></div><p>" +
      esc(i.detail || "No detail emitted.") +
      "</p><code>" +
      esc(i.control_id || "") +
      "</code></article>"
    );
  }
  function renderIso(x) {
    var a = (x.isolation || {}).items || [];
    $("isolation-grid").innerHTML = a.map(iso).join("");
    $("runtime-control-grid").innerHTML = a.map(ctrl).join("");
    var p = a.filter(function (i) {
        return i.status === "PASS";
      }).length,
      n = $("isolation-summary");
    n.textContent = p + "/" + a.length + " passing";
    n.className = "mini-badge " + (p === a.length && a.length ? "" : "warn");
  }
  function rows(a, small) {
    if (!a.length)
      return (
        '<tr><td colspan="' +
        (small ? 6 : 8) +
        '" class="empty-state">No explicit agent/runtime process markers observed.</td></tr>'
      );
    if (small)
      return a
        .slice(0, 7)
        .map(function (e) {
          return (
            '<tr data-searchable><td><span class="entity-name">' +
            esc(e.entity_id) +
            "</span></td><td>" +
            esc(e.family) +
            "</td><td>" +
            esc((e.behavior || []).join(", ")) +
            '</td><td class="confidence">' +
            pct(e.confidence) +
            '</td><td><span class="state-chip ' +
            (e.state === "Runtime" ? "runtime" : "") +
            '">' +
            esc(e.state) +
            "</span></td><td>" +
            ago(e.last_seen) +
            "</td></tr>"
          );
        })
        .join("");
    return a
      .map(function (e) {
        return (
          '<tr data-searchable><td class="entity-name">' +
          esc(e.entity_id) +
          "</td><td>" +
          esc(e.pid) +
          "</td><td>" +
          esc(e.ppid == null ? "—" : e.ppid) +
          "</td><td>" +
          esc(e.family) +
          "<br><small>" +
          esc(e.kind) +
          "</small></td><td><code>" +
          esc(e.executable) +
          "</code></td><td>" +
          esc((e.behavior || []).join(", ")) +
          '</td><td class="confidence">' +
          pct(e.confidence) +
          '</td><td><span class="state-chip ' +
          (e.state === "Runtime" ? "runtime" : "") +
          '">' +
          esc(e.state) +
          "</span></td></tr>"
        );
      })
      .join("");
  }
  function renderEntities(x) {
    var a = x.entities || [];
    $("overview-entity-rows").innerHTML = rows(a, true);
    $("agent-rows").innerHTML = rows(a, false);
    $("agents-count").textContent = num((x.discovery || {}).entity_count);
    $("agents-listeners").textContent = num(((x.discovery || {}).services || {}).listening_tcp);
    $("agents-connections").textContent = num(((x.discovery || {}).services || {}).established_tcp);
  }
  function renderSwarm(x) {
    var a = (x.swarms || {}).clusters || [],
      v = $("swarm-visual");
    if (!a.length) {
      v.className = "swarm-visual empty-state";
      v.textContent = "No correlated cluster observed.";
      $("swarm-detail").innerHTML =
        '<div class="empty-state">No swarm correlation currently meets the two-entity evidence rule.</div>';
      return;
    }
    var c = a[0],
      m = (c.members || []).slice(0, 4);
    v.className = "swarm-visual";
    v.innerHTML =
      '<div class="swarm-node-map" data-searchable><div class="cluster-core">' +
      esc(c.cluster_id) +
      "<br>" +
      pct(c.confidence) +
      "</div>" +
      m
        .map(function (z) {
          return '<span class="cluster-member">' + esc(z) + "</span>";
        })
        .join("") +
      '<div class="cluster-confidence"><i style="width:' +
      Math.round(c.confidence * 100) +
      '%"></i></div></div>';
    $("swarm-detail").innerHTML = a
      .map(function (z) {
        return (
          '<article class="cluster-card" data-searchable><h3>' +
          esc(z.cluster_id) +
          " · " +
          pct(z.confidence) +
          "</h3><p>" +
          esc(z.label) +
          '</p><div class="members">' +
          esc((z.members || []).join(" · ")) +
          "</div><ul>" +
          (z.evidence || [])
            .map(function (e) {
              return "<li>" + esc(e) + "</li>";
            })
            .join("") +
          "</ul></article>"
        );
      })
      .join("");
  }
  function renderAudit(x) {
    var a = x.audit || {},
      ver = a.configured
        ? a.valid === true
          ? "Verified"
          : a.valid === false
            ? "Invalid"
            : "Unknown"
        : "Not configured",
      kv = [
        ["Ledger", a.configured ? a.path : "not configured", ver],
        ["Head checkpoint", hash(a.head_hash), a.valid === true ? "Valid" : "—"],
        [
          "Total records",
          num(a.records),
          a.remote_anchor_configured ? "Remote anchor configured" : "Local only",
        ],
        [
          "Integrity",
          a.error || (a.valid === true ? "No local tampering detected" : "Awaiting ledger"),
          a.valid === true ? "Verified" : "—",
        ],
      ];
    $("audit-summary").innerHTML = kv
      .map(function (r) {
        return (
          '<div class="kv-row" data-searchable><span>' +
          esc(r[0]) +
          "</span><strong>" +
          esc(r[1]) +
          "</strong><em>" +
          esc(r[2]) +
          "</em></div>"
        );
      })
      .join("");
    var cards = [
      ["Configured", a.configured ? "YES" : "NO", a.path || "BULL_AUDIT_LEDGER not set"],
      ["Hash chain", ver, a.error || "Local ledger verification"],
      ["Records", num(a.records), "Full ledger record count"],
      [
        "Remote anchor",
        a.remote_anchor_configured ? "CONFIGURED" : "NO",
        "Configuration presence; not a remote receipt claim",
      ],
    ];
    $("audit-detail-cards").innerHTML = cards
      .map(function (r) {
        return (
          '<article class="panel audit-card" data-searchable><small>' +
          esc(r[0]) +
          "</small><strong>" +
          esc(r[1]) +
          "</strong><p>" +
          esc(r[2]) +
          "</p></article>"
        );
      })
      .join("");
    var rr = a.recent || [];
    $("audit-rows").innerHTML = rr.length
      ? rr
          .map(function (r) {
            return (
              "<tr data-searchable><td>" +
              esc(r.timestamp ? new Date(r.timestamp).toLocaleString() : "—") +
              "</td><td>" +
              esc(r.actor || r.record_type || "—") +
              "</td><td>" +
              esc(r.operation || "—") +
              "</td><td>" +
              esc(r.capability || "—") +
              '</td><td><span class="state-chip">' +
              esc(r.decision || "—") +
              "</span></td><td>" +
              (r.risk == null ? "—" : esc(Number(r.risk).toFixed(2))) +
              "</td><td><code>" +
              esc(r.resource || "—") +
              "</code></td><td>" +
              esc((r.reasons || []).join("; ") || "—") +
              "</td></tr>"
            );
          })
          .join("")
      : '<tr><td colspan="8" class="empty-state">No audit records available.</td></tr>';
  }
  function renderMalware(x) {
    var m = x.malware || {},
      cards = [
        [
          "Scanner",
          m.available ? "AVAILABLE" : "UNAVAILABLE",
          m.engine_path || m.error || "ClamAV path not resolved",
        ],
        [
          "State",
          String(m.status || "unknown").toUpperCase(),
          m.running ? "Bounded scan is running" : "Scanner is idle",
        ],
        ["Files scanned", num(m.files_scanned), "Most recent bounded project scan"],
        [
          "Detections",
          num((m.detections || []).length),
          m.clean === true
            ? "No detections in last completed scan"
            : m.clean === false
              ? "Review detections below"
              : "No completed result",
        ],
      ];
    $("malware-cards").innerHTML = cards
      .map(function (r) {
        return (
          '<article class="panel audit-card" data-searchable><small>' +
          esc(r[0]) +
          "</small><strong>" +
          esc(r[1]) +
          "</strong><p>" +
          esc(r[2]) +
          "</p></article>"
        );
      })
      .join("");
    var d = m.detections || [],
      n = $("malware-detections");
    if (!d.length) {
      n.className = "detection-list empty-state";
      n.textContent =
        m.status === "running"
          ? "Scan running. Detections will appear here."
          : m.error || "No detections recorded.";
    } else {
      n.className = "detection-list";
      n.innerHTML = d
        .map(function (z) {
          return (
            '<article class="detection-row" data-searchable><b>' +
            esc(z.signature) +
            "</b><code>" +
            esc(z.path) +
            "</code><code>sha256 " +
            esc(z.sha256) +
            "</code></article>"
          );
        })
        .join("");
    }
  }
  function renderIntegration(x) {
    var i = x.integration || {},
      names = {
        agent_connector: "Agent connector coverage",
        lifecycle: "Lifecycle governance",
        egress: "Production egress enforcement",
        gateway_systemd: "Systemd gateway KVM candidate",
        gateway_lab: "Networked gateway KVM lab",
        offline_guest: "Guest offline boundary",
        kvm_cases: "Current real-KVM cases",
      },
      n = $("integration-grid");
    n.innerHTML = Object.keys(names)
      .map(function (k) {
        var v = i[k] || { status: "UNAVAILABLE", detail: "No evidence supplied" };
        return (
          '<article class="control-card" data-searchable><div class="control-head"><h3>' +
          esc(names[k]) +
          '</h3><span class="control-status ' +
          cls(v.status) +
          '">' +
          esc(v.status) +
          "</span></div><p>" +
          esc(v.detail) +
          "</p><small>" +
          esc(v.evidence || "") +
          "</small></article>"
        );
      })
      .join("");
  }
  function renderVM(x) {
    var m = x.microvm || {},
      a = [
        [
          "KVM device",
          m.kvm_available ? "PASS" : "BLOCKED",
          m.kvm_available ? "/dev/kvm is read/write" : "/dev/kvm unavailable",
        ],
        [
          "QEMU",
          m.qemu_available ? "PASS" : "BLOCKED",
          m.qemu_path || "qemu-system-x86_64 not found",
        ],
        [
          "Trusted config",
          m.config_exists || (m.kernel_configured && m.rootfs_configured) ? "PASS" : "BLOCKED",
          m.config_file || "Kernel/rootfs must be configured",
        ],
        [
          "MicroVM process",
          m.running ? "PASS" : "BLOCKED",
          m.running
            ? "QEMU MicroVM process observed"
            : "No matching MicroVM process currently observed",
        ],
        [
          "Readiness",
          m.ready ? "PASS" : "BLOCKED",
          m.ready
            ? "Host inputs required by launcher are present"
            : "One or more launch prerequisites are missing",
        ],
        [
          "Acceleration",
          String(m.accel || "kvm").toUpperCase(),
          "Existing launcher rejects software fallback in production path",
        ],
        ["Memory", (m.memory_mib || "4096") + " MiB", "Configured MicroVM memory"],
        ["vCPU", m.cpus || "2", "Configured MicroVM CPU count"],
        [
          "Console ownership",
          m.managed_running
            ? "RUNNING"
            : m.managed_exit_code == null
              ? "IDLE"
              : "EXIT " + m.managed_exit_code,
          m.managed_running
            ? "This console owns the active MicroVM launcher"
            : m.managed_log || "No managed launch yet",
        ],
      ];
    $("microvm-grid").innerHTML = a
      .map(function (r) {
        return (
          '<article class="control-card" data-searchable><div class="control-head"><h3>' +
          esc(r[0]) +
          '</h3><span class="control-status ' +
          cls(r[1]) +
          '">' +
          esc(r[1]) +
          "</span></div><p>" +
          esc(r[2]) +
          "</p></article>"
        );
      })
      .join("");
  }
  function renderAtt(x) {
    var a = x.attestation || {},
      cs = a.controls || [],
      ct = {};
    cs.forEach(function (c) {
      ct[c.status] = (ct[c.status] || 0) + 1;
    });
    var cards = [
      [
        "Probe",
        String(a.status || "pending").toUpperCase(),
        a.dynamic ? "Dynamic backend attestation requested" : "Static/source assurance",
      ],
      ["PASS", num(ct.PASS), "Deployment controls proven by current probe"],
      ["BLOCKED / FAIL", num((ct.BLOCKED || 0) + (ct.FAIL || 0)), "Visible unresolved controls"],
      [
        "Source complete",
        a.source_complete === true ? "YES" : a.source_complete === false ? "NO" : "PENDING",
        "Source evidence profile only",
      ],
    ];
    $("attestation-cards").innerHTML = cards
      .map(function (r) {
        return (
          '<article class="panel audit-card" data-searchable><small>' +
          esc(r[0]) +
          "</small><strong>" +
          esc(r[1]) +
          "</strong><p>" +
          esc(r[2]) +
          "</p></article>"
        );
      })
      .join("");
    $("attestation-rows").innerHTML = cs.length
      ? cs
          .map(function (c) {
            return (
              '<tr data-searchable><td class="entity-name">' +
              esc(c.id) +
              "<br><small>" +
              esc(c.title || "") +
              "</small></td><td>" +
              esc(c.phase || "") +
              '</td><td><span class="control-status ' +
              cls(c.status) +
              '">' +
              esc(c.status) +
              "</span></td><td>" +
              esc(c.detail || "") +
              "</td></tr>"
            );
          })
          .join("")
      : '<tr><td colspan="4" class="empty-state">' +
        esc(a.error || "Assurance probe has not completed.") +
        "</td></tr>";
  }
  function renderEvents(x) {
    var a = x.events || [];
    $("event-list").innerHTML = a.length
      ? a
          .map(function (e) {
            return (
              '<div class="event-row ' +
              cls(e.level) +
              '" data-searchable><time>' +
              esc(e.timestamp ? new Date(e.timestamp).toLocaleString() : "") +
              "</time><b>" +
              esc(e.type) +
              "</b><span>" +
              esc(e.message) +
              "</span></div>"
            );
          })
          .join("")
      : '<div class="empty-state">No control-plane events yet.</div>';
  }
  function renderSettings(x) {
    var m = x.meta || {},
      a = [
        ["Workspace", m.workspace],
        ["State directory", m.state_dir],
        ["Console URL", m.launch_url || location.href],
        ["Hostname", m.hostname],
        ["Platform", m.platform],
        ["Version", m.version],
        ["Refresh interval", (m.refresh_seconds || 0) + "s"],
        [
          "Console policy",
          "bounded operator controls; no arbitrary shell or generic host process kill",
        ],
      ];
    $("settings-list").innerHTML = a
      .map(function (r) {
        return (
          '<article class="setting-card" data-searchable><small>' +
          esc(r[0]) +
          "</small><strong>" +
          esc(r[1] || "—") +
          "</strong></article>"
        );
      })
      .join("");
  }
  function renderHealth(x) {
    var h = x.system_health || {},
      a = x.attestation || {};
    $("metric-entities").textContent = num(h.observed_entities);
    $("metric-denied").textContent = num(h.denied_actions);
    $("metric-malware").textContent = num(h.malware_detections);
    $("metric-audit").textContent = num(h.audit_records);
    $("metric-protection").textContent =
      num(h.protections_passing) + "/" + num(h.protections_total);
    var b = $("health-badge");
    b.textContent = h.operational ? "● observer operational" : "● attention required";
    b.className = "mini-badge " + (h.operational ? "" : "warn");
    var r = $("runtime-pill");
    if (a.deployment_complete === true) {
      r.innerHTML = "<i></i> Protected Runtime";
      r.className = "status-pill good";
    } else if (a.status === "error") {
      r.innerHTML = "<i></i> Runtime Probe Error";
      r.className = "status-pill bad";
    } else {
      r.innerHTML = "<i></i> Runtime State Visible";
      r.className = "status-pill warn";
    }
    $("mini-bars").innerHTML = "";
  }
  function render(x) {
    S.snapshot = x;
    $("version-label").textContent = "v" + ((x.meta || {}).version || "source");
    $("scan-age").textContent = "Last scan: " + ago((x.meta || {}).updated_at);
    renderHealth(x);
    renderIntegration(x);
    renderDecisions(x);
    renderCaps(x);
    renderIso(x);
    renderEntities(x);
    renderSwarm(x);
    renderAudit(x);
    renderMalware(x);
    renderVM(x);
    renderAtt(x);
    renderEvents(x);
    renderSettings(x);
    search();
  }
  async function refresh() {
    try {
      var r = await api("/api/v1/snapshot", { cache: "no-store" });
      if (r.status === 401)
        throw new Error("open the full URL printed by the console; it holds this run's access key");
      if (!r.ok) throw new Error("snapshot HTTP " + r.status);
      render(await r.json());
    } catch (e) {
      toast("Console refresh failed: " + e.message, "error");
      var n = $("runtime-pill");
      n.innerHTML = "<i></i> Console Disconnected";
      n.className = "status-pill bad";
    }
  }
  async function action(name, body) {
    var r = await api("/api/v1/actions/" + name, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body || {}),
      }),
      d = await r.json().catch(function () {
        return { error: "HTTP " + r.status };
      });
    if (!r.ok || d.error || d.ok === false)
      throw new Error(d.error || d.message || "HTTP " + r.status);
    toast(d.message || "Action complete.", "success");
    await refresh();
    return d;
  }
  function search() {
    var q = S.q.trim().toLowerCase();
    $$("[data-searchable]").forEach(function (n) {
      n.classList.toggle("search-hidden", !!q && n.textContent.toLowerCase().indexOf(q) < 0);
    });
  }
  $$(".nav-item").forEach(function (b) {
    b.addEventListener("click", function () {
      setView(b.dataset.view);
    });
  });
  $$("[data-nav]").forEach(function (b) {
    b.addEventListener("click", function () {
      setView(b.dataset.nav);
    });
  });
  $$("[data-action]").forEach(function (b) {
    b.addEventListener("click", async function () {
      b.disabled = true;
      try {
        await action(b.dataset.action);
      } catch (e) {
        toast(e.message, "error");
      } finally {
        b.disabled = false;
      }
    });
  });
  var si = $("global-search");
  si.addEventListener("input", function () {
    S.q = si.value;
    search();
  });
  document.addEventListener("keydown", function (e) {
    if (
      e.key === "/" &&
      document.activeElement !== si &&
      !/INPUT|TEXTAREA|SELECT/.test((document.activeElement || {}).tagName || "")
    ) {
      e.preventDefault();
      si.focus();
    }
    if (e.key === "Escape" && document.activeElement === si) {
      si.value = "";
      S.q = "";
      si.blur();
      search();
    }
  });
  var caps = [
      "fs.read.project",
      "fs.write.project",
      "fs.read.home",
      "fs.write.home",
      "credential.read",
      "process.exec",
      "network.outbound",
      "network.post",
      "package.install",
      "agent.spawn",
      "agent.message",
      "security_control.write",
    ],
    prov = ["human", "local_trusted", "repository", "internet", "external_agent", "unknown"];
  $("policy-capability").innerHTML = caps
    .map(function (x) {
      return (
        '<option value="' +
        esc(x) +
        '"' +
        (x === "process.exec" ? " selected" : "") +
        ">" +
        esc(x) +
        "</option>"
      );
    })
    .join("");
  $("policy-provenance").innerHTML = prov
    .map(function (x) {
      return (
        '<option value="' +
        esc(x) +
        '"' +
        (x === "unknown" ? " selected" : "") +
        ">" +
        esc(x) +
        "</option>"
      );
    })
    .join("");
  $("policy-form").addEventListener("submit", async function (e) {
    e.preventDefault();
    var f = new FormData(e.currentTarget),
      c = String(f.get("capability")),
      p = {
        actor: String(f.get("actor") || ""),
        operation: String(f.get("operation") || ""),
        resource: String(f.get("resource") || ""),
        capability: c,
        granted_capabilities: [c],
        provenance: [String(f.get("provenance") || "unknown")],
        external_side_effect: f.get("external_side_effect") === "on",
        irreversible: f.get("irreversible") === "on",
      },
      b = e.currentTarget.querySelector("button[type=submit]");
    b.disabled = true;
    try {
      var r = await api("/api/v1/actions/policy-evaluate", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(p),
        }),
        d = await r.json();
      if (!r.ok || d.error) throw new Error(d.error || "HTTP " + r.status);
      var z = d.result,
        n = $("policy-result");
      n.className = "decision-result";
      n.innerHTML =
        "<h3>" +
        esc(z.decision) +
        "</h3><p>Risk " +
        esc(Number(z.risk).toFixed(2)) +
        " · " +
        (z.hard_block ? "hard block" : "policy result") +
        "</p><ul>" +
        (z.reasons || [])
          .map(function (q) {
            return "<li>" + esc(q) + "</li>";
          })
          .join("") +
        "</ul>";
      toast("Policy result: " + z.decision, "success");
      await refresh();
    } catch (x) {
      toast(x.message, "error");
    } finally {
      b.disabled = false;
    }
  });
  refresh();
  setInterval(refresh, 2000);
})();
