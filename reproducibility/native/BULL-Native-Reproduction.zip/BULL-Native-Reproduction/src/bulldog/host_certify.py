"""Probe host prerequisites and collect live sandbox attestation.

Missing protections remain failures; a static feature listing is not a live test."""

from __future__ import annotations

import ctypes.util
import os
from pathlib import Path
import shutil
import tempfile


def certify_host(
    *,
    dynamic: bool = False,
    seccomp_profile: str = "strict",
) -> dict:
    """Certify the host capabilities BULL depends on."""

    try:
        from .seccomp_policy import _load_libseccomp

        _load_libseccomp()
        seccomp_loadable = True
    except (OSError, RuntimeError):
        seccomp_loadable = False
    checks = {
        "linux": os.name == "posix",
        "unshare": shutil.which("unshare") is not None,
        "mount": shutil.which("mount") is not None,
        "chroot": shutil.which("chroot") is not None,
        "true": shutil.which("true") is not None,
        "network_namespace": Path("/proc/self/ns/net").exists(),
        "pid_namespace": Path("/proc/self/ns/pid").exists(),
        "mount_namespace": Path("/proc/self/ns/mnt").exists(),
        "user_namespace": Path("/proc/self/ns/user").exists(),
        "cgroup_v2": Path("/sys/fs/cgroup/cgroup.controllers").exists(),
        "libseccomp": seccomp_loadable,
    }

    result = {
        "checks": checks,
        "static_certified": all(checks.values()),
        "dynamic_requested": bool(dynamic),
        "dynamic_certified": None,
        "dynamic_error": None,
        "attestation": None,
    }

    if dynamic:
        if not result["static_certified"]:
            result["dynamic_certified"] = False
            result["dynamic_error"] = "static prerequisites failed"
        else:
            try:
                from .namespace_sandbox import NamespaceSandbox

                with tempfile.TemporaryDirectory(prefix="bull_certify_") as td:
                    sandbox = NamespaceSandbox(
                        seccomp_profile=seccomp_profile,
                        require_attestation=True,
                    )
                    probe = sandbox.run(
                        [shutil.which("true") or "/usr/bin/true"],
                        project_root=td,
                        writable=False,
                        timeout=10.0,
                    )

                att = probe.attestation
                strict_landlock_ok = seccomp_profile != "strict" or (
                    att is not None and att.landlock and att.landlock_abi >= 1
                )
                result["dynamic_certified"] = bool(
                    probe.returncode == 0
                    and att is not None
                    and att.pid == 1
                    and att.no_new_privs
                    and att.seccomp
                    and att.seccomp_profile == seccomp_profile
                    and strict_landlock_ok
                    and att.network_isolated
                    and att.runtime_root == "/bull_runtime"
                )
                if att is not None:
                    result["attestation"] = {
                        "pid": att.pid,
                        "no_new_privs": att.no_new_privs,
                        "seccomp": att.seccomp,
                        "seccomp_profile": att.seccomp_profile,
                        "seccomp_rules": att.seccomp_rules,
                        "landlock": att.landlock,
                        "landlock_abi": att.landlock_abi,
                        "network_interfaces": list(att.network_interfaces),
                        "network_isolated": att.network_isolated,
                        "python": att.python,
                        "runtime_root": att.runtime_root,
                    }
                if not result["dynamic_certified"]:
                    result["dynamic_error"] = (
                        probe.stderr.strip()
                        or "backend attestation did not satisfy production requirements"
                    )
            except Exception as exc:
                result["dynamic_certified"] = False
                result["dynamic_error"] = f"{type(exc).__name__}: {exc}"

    result["certified"] = bool(
        result["static_certified"]
        and (not dynamic or result["dynamic_certified"] is True)
    )
    return result
