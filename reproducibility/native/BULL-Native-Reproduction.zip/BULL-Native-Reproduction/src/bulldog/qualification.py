"""Validate private KVM reports and return bounded summaries for the console.

Report checks establish consistency and source identity, not independent
attestation. Older source revisions remain STALE even when their tests passed.
"""

from __future__ import annotations

import json
from pathlib import Path
import re

CASES = ("allowed", "denied", "timeout", "cancel", "missing-protection")
GATEWAY_CHECKS = {
    "gateway_uid",
    "agent_workload_uid",
    "direct_gateway_http",
    "allowed_http",
    "denied_http",
    "ipv4_alt_closed",
    "ipv6_alt_closed",
    "ipv6_web_closed",
    "filter_drop_counters",
    "denied_dns",
    "gateway_down_closed",
    "restart_still_denies",
}
HEX64 = re.compile(r"[0-9a-f]{64}\Z")
HEX40 = re.compile(r"[0-9a-f]{40}\Z")


def _read(path: Path) -> dict:
    if path.is_symlink() or not path.is_file() or path.stat().st_size > 1024 * 1024:
        raise ValueError("missing, linked or oversized qualification report")
    value = json.loads(path.read_text(encoding="utf-8"))
    if type(value) is not dict:
        raise ValueError("qualification report is not an object")
    return value


def summarize_kvm(
    directory: str | Path, *, current_commit: str | None
) -> dict[str, str]:
    """Check five private reports; expose no paths, sessions, keys or raw events."""
    try:
        root = Path(directory)
        if root.is_symlink() or not root.is_dir():
            raise ValueError("qualification directory unavailable")
        setup = _read(root / "setup-report.json")
        summary = _read(root / "cases/summary.json")
        revision = setup.get("source_commit")
        assets = setup.get("asset_sha256")
        trees = summary.get("source_tree_sha256")
        if (
            setup.get("status") != "PASS"
            or setup.get("source_dirty") is not False
            or type(setup.get("kvm")) is not dict
            or setup["kvm"].get("status") != "PASS"
            or type(revision) is not str
            or not HEX40.fullmatch(revision)
            or type(assets) is not dict
            or set(assets) != {"kernel", "rootfs", "firmware"}
            or any(
                type(v) is not str or not HEX64.fullmatch(v) for v in assets.values()
            )
            or summary.get("status") != "PASS"
            or type(trees) is not list
            or len(trees) != 1
            or type(trees[0]) is not str
            or not HEX64.fullmatch(trees[0])
            or summary.get("cases") != {name: "PASS" for name in CASES}
        ):
            raise ValueError("incomplete five-case qualification summary")
        for name in CASES:
            case = _read(root / "cases" / name / "report.json")
            if (
                case.get("status") != "PASS"
                or case.get("case") != name
                or case.get("revision") != revision
                or case.get("assets") != assets
                or case.get("source_tree_sha256") != trees[0]
                or case.get("external_collector") is not False
            ):
                raise ValueError("case identity or result mismatch")
        if current_commit != revision:
            return {
                "status": "STALE",
                "detail": "Five guest cases passed for a different source revision.",
                "evidence": f"Operator-selected private reports: {revision[:12]} (one-shot fixture)",
            }
        return {
            "status": "PASS",
            "detail": "Five real-KVM one-shot cases passed for this source revision.",
            "evidence": f"Operator-selected private reports: {revision[:12]}; disposable local TLS collector",
        }
    except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError):
        return {
            "status": "INVALID",
            "detail": "Selected KVM evidence is missing, incomplete or inconsistent.",
            "evidence": "No qualification claim made",
        }


def summarize_offline_egress(
    directory: str | Path, *, current_commit: str | None
) -> dict[str, str]:
    """Check a separate guest-offline fixture without implying gateway enforcement."""
    try:
        root = Path(directory)
        if root.is_symlink() or not root.is_dir():
            raise ValueError("offline evidence directory unavailable")
        setup = _read(root / "setup-report.json")
        case = _read(root / "offline-egress/report.json")
        revision = setup.get("source_commit")
        assets = setup.get("asset_sha256")
        fixture = case.get("offline_egress")
        if (
            setup.get("status") != "PASS"
            or setup.get("source_dirty") is not False
            or type(setup.get("kvm")) is not dict
            or setup["kvm"].get("status") != "PASS"
            or type(revision) is not str
            or not HEX40.fullmatch(revision)
            or type(assets) is not dict
            or set(assets) != {"kernel", "rootfs", "firmware"}
            or any(
                type(v) is not str or not HEX64.fullmatch(v) for v in assets.values()
            )
            or case.get("status") != "PASS"
            or case.get("case") != "offline-egress"
            or case.get("revision") != revision
            or case.get("assets") != assets
            or case.get("qemu_network") != "none (observed child command line)"
            or type(case.get("source_tree_sha256")) is not str
            or not HEX64.fullmatch(case["source_tree_sha256"])
            or type(fixture) is not dict
            or type(fixture.get("denials")) is not dict
            or set(fixture["denials"]) != {"ipv4", "ipv6"}
            or any(
                v
                not in {
                    "EPERM",
                    "EACCES",
                    "ENETUNREACH",
                    "EHOSTUNREACH",
                    "ENETDOWN",
                    "EAFNOSUPPORT",
                    "EPROTONOSUPPORT",
                    "ENODEV",
                }
                for v in fixture["denials"].values()
            )
            or case.get("external_collector") is not False
        ):
            raise ValueError("incomplete offline guest evidence")
        if current_commit != revision:
            return {
                "status": "STALE",
                "detail": "Offline guest test belongs to another source revision.",
                "evidence": f"Private guest report: {revision[:12]}",
            }
        return {
            "status": "OFFLINE PASS",
            "detail": "KVM guest workload denied IPv4/IPv6 outbound connections; QEMU -net none observed.",
            "evidence": f"Private guest report: {revision[:12]}; gateway deployment not tested",
        }
    except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError):
        return {
            "status": "INVALID",
            "detail": "Offline guest evidence is missing or inconsistent.",
            "evidence": "No guest network claim made",
        }


def summarize_gateway_lab(
    directory: str | Path, *, current_commit: str | None
) -> dict[str, str]:
    """Expose only a validated, revision-bound networked guest lab summary."""
    try:
        root = Path(directory)
        if root.is_symlink() or not root.is_dir():
            raise ValueError("gateway lab directory unavailable")
        setup = _read(root / "setup-report.json")
        revision = setup.get("source_commit")
        assets = setup.get("guest_assets")
        guest = setup.get("guest_result")
        if (
            setup.get("status") != "PASS"
            or setup.get("source_dirty") is not False
            or type(setup.get("kvm")) is not dict
            or setup["kvm"].get("status") != "PASS"
            or type(revision) is not str
            or not HEX40.fullmatch(revision)
            or type(assets) is not dict
            or set(assets) != {"kernel", "initrd", "rootfs"}
            or any(
                type(v) is not str or not HEX64.fullmatch(v) for v in assets.values()
            )
            or type(guest) is not dict
            or guest.get("status") != "PASS"
            or guest.get("scope")
            != (
                "disposable Debian KVM lab guest, restricted QEMU user "
                "networking; direct init startup, no systemd or production image"
            )
            or type(guest.get("checks")) is not dict
            or set(guest["checks"]) != GATEWAY_CHECKS
            or any(v is not True for v in guest["checks"].values())
        ):
            raise ValueError("incomplete gateway lab report")
        if current_commit != revision:
            return {
                "status": "STALE",
                "detail": "Networked gateway lab passed for a different source revision.",
                "evidence": f"Private KVM lab report: {revision[:12]}; production guest unverified",
            }
        return {
            "status": "PASS",
            "detail": "12 networked KVM gateway checks passed from a dedicated agent UID.",
            "evidence": f"Private KVM lab report: {revision[:12]}; no production image or systemd claim",
        }
    except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError):
        return {
            "status": "INVALID",
            "detail": "Selected networked KVM lab report is incomplete or inconsistent.",
            "evidence": "No gateway lab claim made",
        }


def summarize_gateway_systemd(
    directory: str | Path, *, current_commit: str | None
) -> dict[str, str]:
    """Validate the separate systemd candidate without promoting production egress."""
    try:
        root = Path(directory)
        if root.is_symlink() or not root.is_dir():
            raise ValueError("systemd candidate directory unavailable")
        setup = _read(root / "setup-report.json")
        revision = setup.get("source_commit")
        assets = setup.get("guest_assets")
        guest = setup.get("guest_result")
        expected = GATEWAY_CHECKS | {"service_units_active"}
        if (
            setup.get("status") != "PASS"
            or setup.get("source_dirty") is not False
            or type(setup.get("kvm")) is not dict
            or setup["kvm"].get("status") != "PASS"
            or type(revision) is not str
            or not HEX40.fullmatch(revision)
            or type(assets) is not dict
            or set(assets) != {"kernel", "initrd", "rootfs"}
            or any(
                type(v) is not str or not HEX64.fullmatch(v) for v in assets.values()
            )
            or setup.get("scope")
            != "disposable Debian networked KVM systemd candidate; not the pinned production image"
            or type(guest) is not dict
            or guest.get("status") != "PASS"
            or set(guest.get("checks", {})) != expected
            or any(v is not True for v in guest["checks"].values())
        ):
            raise ValueError("incomplete systemd candidate report")
        if current_commit != revision:
            return {
                "status": "STALE",
                "detail": "Systemd gateway candidate passed for another source revision.",
                "evidence": f"Private candidate report: {revision[:12]}",
            }
        return {
            "status": "CANDIDATE PASS",
            "detail": "13 KVM checks passed: agent UID, gateway policy, restart and actual systemd units.",
            "evidence": f"Private candidate report: {revision[:12]}; pinned production image remains separate",
        }
    except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError):
        return {
            "status": "INVALID",
            "detail": "Selected systemd candidate evidence is incomplete or inconsistent.",
            "evidence": "No deployed production claim made",
        }
