#!/usr/bin/env python3
"""Run the real OpenShell integration. Missing prerequisites are BLOCKED."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "tools"))
from openshell_qualification_results import BINARIES, preflight


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--os-src", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--check", action="store_true")
    args = p.parse_args()
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False, mode=0o700)
    report = {"status": "BLOCKED", "native_executed": False,
              "started_utc": datetime.now(timezone.utc).isoformat(),
              "scope": "Local native OpenShell integration; no MCP session or SAF certification",
              "source": "SOURCE_SHA256SUMS in the supplied archive"}
    code = 2
    try:
        if platform.system() != "Linux" or platform.machine() != "x86_64":
            raise RuntimeError("Requires Linux x86-64 with a local Docker daemon")
        if preflight(out, str(args.os_src.resolve())):
            report["reason"] = "Native prerequisites missing; see native-preflight.json"
            return code
        if args.check:
            report.update(status="READY", reason="Prerequisites found; native tests not run")
            code = 0
            return code
        endpoint = os.environ.get("DOCKER_HOST", "")
        if not endpoint:
            context = json.loads(subprocess.check_output(["docker", "context", "inspect"], text=True))
            endpoint = context[0]["Endpoints"]["docker"]["Host"]
        if not endpoint.startswith("unix://"):
            report["reason"] = "A local Docker Unix socket is required; remote contexts are unsupported"
            return code
        source_hashes = {str(p.relative_to(ROOT)): digest(p)
                         for folder in ("src", "tools", "examples/saf_native")
                         for p in sorted((ROOT / folder).rglob("*"))
                         if p.is_file() and "__pycache__" not in p.parts}
        binary_hashes = {name: digest(args.os_src / name) for name in BINARIES}
        save(out / "provenance.json", {
            "started_utc": report["started_utc"], "kernel": platform.release(),
            "python": sys.version, "source_sha256": source_hashes,
            "openshell_binary_sha256": binary_hashes,
            "dependencies": subprocess.check_output(
                [sys.executable, "-m", "pip", "freeze"], text=True).splitlines()})
        command = [sys.executable, str(ROOT / "tools/openshell_experiment.py"),
                   "--os-src", str(args.os_src.resolve()),
                   "--output", str(out / "native"), "--latency-n", "20"]
        report["command"] = command
        report["native_attempted"] = True
        with (out / "runner.log").open("w") as log:
            code = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT,
                                  env={**os.environ, "PYTHONPATH": str(ROOT / "src")}).returncode
        result_file = out / "native/results.json"
        result = json.loads(result_file.read_text()) if result_file.exists() else {}
        rows = result.get("results", [])
        unchanged = all(digest(ROOT / name) == value for name, value in source_hashes.items())
        unchanged &= all(digest(args.os_src / name) == value for name, value in binary_hashes.items())
        complete = all(any(r["phase"] == phase and r["case"] == case for r in rows)
                       for phase, cases in [("A-openshell-only", ["C1", "C2", "C3", "C8"]),
                                            ("B-openshell+bull", ["C1", "C2", "C3", "C4", "C8", "C9", "C10"])]
                       for case in cases)
        passed = code == 0 and complete and unchanged and all(r.get("pass") is True for r in rows)
        report.update(status="PASS" if passed else "FAIL", inputs_unchanged=unchanged,
                      native_executed=complete,
                      cases_file="native/results.json", destination_file="native/destination.jsonl")
        code = 0 if passed else 1
        for label in ("bull-local/openshell-supervisor:bull-exp",
                      "bull-local/openshell-sandbox:bull-exp", "bull-local/openshell-base:ubuntu24.04"):
            image = subprocess.run(["docker", "image", "inspect", label], capture_output=True, text=True)
            with (out / "images.jsonl").open("a") as stream:
                stream.write(json.dumps({"image": label, "returncode": image.returncode,
                                         "inspect": image.stdout, "stderr": image.stderr}) + "\n")
    except Exception as exc:
        report.update(status="FAIL", reason=f"{type(exc).__name__}: {exc}")
        code = 1
    finally:
        report.update(exit_code=code, finished_utc=datetime.now(timezone.utc).isoformat())
        save(out / "report.json", report)
        files = [p for p in sorted(out.rglob("*")) if p.is_file() and not p.is_symlink()]
        (out / "SHA256SUMS").write_text("".join(f"{digest(p)}  {p.relative_to(out)}\n" for p in files))
        print(json.dumps(report, indent=2))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
