#!/usr/bin/env python3
"""Package native source and dependencies; never manufacture run evidence."""
import argparse
import hashlib
from pathlib import Path
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[2]


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--wheels", type=Path, required=True)
    p.add_argument("--host-check", type=Path, required=True)
    args = p.parse_args()
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    tracked = subprocess.check_output(["git", "ls-files"], cwd=ROOT, text=True).splitlines()
    prefixes = ("src/", "examples/saf_native/", "docs/evidence/openshell-20260928/")
    names = {n for n in tracked if n.startswith(prefixes)}
    names.update({"LICENSE", "THIRD_PARTY_NOTICES.md", "pyproject.toml", "README.md",
        "tools/openshell_experiment.py", "tools/prepare_codespace_openshell.py",
        "tools/openshell_qualification_results.py"})
    for name in sorted(names):
        target = out / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / name, target)
    shutil.copyfile(ROOT / "examples/saf_native/README.md", out / "START_HERE.md")
    for name in ("main.tex", "main.pdf", "IEEEtran.cls"):
        target = out / "paper" / name
        target.parent.mkdir(exist_ok=True)
        shutil.copyfile(ROOT / "docs/papers/saf-containment-20261013" / name, target)
    (out / "wheels").mkdir()
    for prefix in ("grpcio-1.84.0-", "protobuf-7.36.2-", "typing_extensions-4.16.0-"):
        matches = list(args.wheels.glob(prefix + "*.whl"))
        if len(matches) != 1:
            raise RuntimeError("Expected one wheel for " + prefix)
        shutil.copyfile(matches[0], out / "wheels" / matches[0].name)
    shutil.copytree(args.host_check, out / "host-check")
    (out / "SOURCE_COMMIT").write_text(subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True))
    files = sorted(p for p in out.rglob("*") if p.is_file())
    (out / "SOURCE_SHA256SUMS").write_text("".join(
        f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(out)}\n" for p in files))
    with zipfile.ZipFile(out.with_suffix(".zip"), "w", zipfile.ZIP_DEFLATED) as z:
        for file in sorted(out.rglob("*")):
            if file.is_file():
                z.write(file, str(Path(out.name) / file.relative_to(out)))
    print(out.with_suffix(".zip"))


if __name__ == "__main__":
    main()
