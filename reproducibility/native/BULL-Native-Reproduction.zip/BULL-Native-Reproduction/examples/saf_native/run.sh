#!/usr/bin/env bash
set -euo pipefail
root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)
if [[ $# -ne 2 ]]; then
  echo 'Usage: bash examples/saf_native/run.sh /absolute/OpenShell /absolute/new-results' >&2
  exit 2
fi
os_source=$(realpath -m -- "$1")
results=$(realpath -m -- "$2")
if [[ -f "$root/SOURCE_SHA256SUMS" ]]; then
  (cd "$root" && sha256sum --quiet -c SOURCE_SHA256SUMS)
fi
# Check the actual host before installing anything. Failure leaves a BLOCKED report.
python3 "$root/examples/saf_native/run.py" --os-src "$os_source" --output "$results-preflight" --check
environment=$(mktemp -d /tmp/bull-native-python-XXXXXXXX)
trap 'rm -rf -- "$environment"' EXIT
python3.12 -m venv "$environment"
"$environment/bin/python" -m pip install --no-index --find-links "$root/wheels" -r "$root/examples/saf_native/requirements.txt"
"$environment/bin/python" "$root/examples/saf_native/run.py" --os-src "$os_source" --output "$results"
